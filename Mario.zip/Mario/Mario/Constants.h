#pragma once

//Screen Dimesions
#define SCREEN_WIDTH 512
#define SCREEN_HEIGHT 416
