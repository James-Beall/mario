#include<SDL.h>
#include<SDL_image.h>
#include<SDL_mixer.h>
#include"Constants.h"
#include<iostream>

using namespace::std;

//Globals
SDL_Window* gWindow = NULL;

//Function Prototypes
bool InitSDL();
void CloseSDL();
bool Update();

int main(int argc, char* args[])
{
	// Checks if SDL was set up correctly 
	if (InitSDL())
	{
		// Flag to check if we wish to quit
		bool quit = false;

		// Game Loop
		while (!quit)
		{
			quit = Update();
		}
		
	}
	//Close Window and free resources
	CloseSDL();
	return 0;
}

bool InitSDL()
{
	//Setup SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		cout << "SDL did not initalise. Error" << SDL_GetError();
		return false;
	}
	else
	{
		// All good, si attenot to create window 
		gWindow = SDL_CreateWindow("Game Engine Creation", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	}
	// Did the window get created?
	if (gWindow == NULL)
	{
		// Nope
		cout << "Window was not created. Error:" << SDL_GetError();
		return false;
	}
	return true;
}

void CloseSDL()
{
	// Release memory 
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;

	//Quit SDL subsystem
	IMG_Quit();
	SDL_Quit();

}

bool Update()
{
	// Event Handler 
	SDL_Event e;

	// Get the Events
	SDL_PollEvent(&e);

	switch (e.type)
	{
		// Click the 'X' to quit
	case SDL_QUIT:
			return true;
			break;
	}
	return false;
}